Creating a message archive page
-------

Copy archive.php into the publically accessible root folder of your PHPList installation (i.e., the same folder where index.php is)