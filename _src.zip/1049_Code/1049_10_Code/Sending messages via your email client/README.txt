Sending messages via your email client
-------

The mail2listv2_0_0b structure is as follows:

mail2listv2_0_0b/m2l_cron.php
mail2listv2_0_0b/plugins/mailtolist.php
mail2listv2_0_0b/plugins/mailtolist/main.php
mail2listv2_0_0b/plugins/mailtolist/get_email.class.php

Copy m2l_cron.php into the publically accessible root folder of your PHPList installation (i.e., the same folder where index.php is)

Copy the mailtolist.php, as well as the mailtolist folder, into your admin/plugins/ directory.